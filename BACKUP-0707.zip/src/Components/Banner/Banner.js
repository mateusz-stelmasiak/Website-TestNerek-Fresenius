import "./Banner.css"
import logo from '../../Assets/freseniusLogo.png';

function Banner(){
    return (
        <section className="Banner">
            <div className="contentContainer">
                <img src={logo} alt="logo"/>
                <h1>OGÓLNOPOLSKI <br/> TEST ZDROWIA NEREK</h1>
                <p>Nerki to filtr życia, który odpowiada za prawidłowe funkcjonowanie wszystkich głównych narządów. Choroby
                    nerek przebiegają bardzo długo bezobjawowo i bardzo często są wykrywane dopiero gdy są one już zupełnie
                    zniszczone. Życie chorego mogą wtedy uratować wyłącznie przeszczep lub dializa. Test nie zastępuje wizyty u
                    lekarza, lecz może Ci pomóc uratować nerki.</p>
            </div>
        </section>
    );
}
export default Banner;