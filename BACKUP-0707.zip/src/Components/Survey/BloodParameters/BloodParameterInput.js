import React, {useState} from "react";
import {selectAnswers} from "../../../Redux/Actions/surveyActions";
import {connect} from "react-redux";
import "./BloodParameterInput.css"
import {Form} from "react-bootstrap";


function BloodParameterInput({qId,pName,pNorms,pUnits,dispatch}){
    //holds chosen indices answers in an array
    const [pLevel,setPLevel] = useState(undefined)
    const [chosenUnit,setChosenUnit] = useState(0)


    function setParamValue(paramValue){
        //cap max digts
        if(paramValue>9999) return
        
        setPLevel(paramValue);
        //save answers to the store
        paramValue>pNorms[chosenUnit] ? dispatch(selectAnswers(qId,0)):dispatch(selectAnswers(qId,1));
    }

    return (
        <Form.Group  className="SurveyAnswer">
            <Form.Label><b>{pName}:</b></Form.Label>
            <Form.Control
                className="sixCharInput"
                type="number"
                value={pLevel}
                onChange={(e) => setParamValue(e.target.value)}
            />
            {pUnits.length>0 &&
                <Form.Group>
                    <Form.Label>Jednostka: </Form.Label>
                    <Form.Control as="select" onChange={(e) => setChosenUnit(e.target.value)}>
                        {pUnits.map((unit,index)=>{
                           return <option  key={index} value={index}>{unit}</option>
                        })}
                    </Form.Control>
                </Form.Group>
            }

        </Form.Group>
    );
}

export default connect()(BloodParameterInput);