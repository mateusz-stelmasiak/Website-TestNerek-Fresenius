import "./UnderConstruction.css"

export default function UnderConstruction(){
    return(
        <div className="UnderConstruction">
            <h1>Strona w przygotowaniu</h1>
            <h2>spróbuj ponownie później</h2>
        </div>

    );
}