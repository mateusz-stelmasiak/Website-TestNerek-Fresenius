import "./Partners.css"

function Partners(){
    return (
        <section className="Partners">
        </section>
    );
}
export default Partners;