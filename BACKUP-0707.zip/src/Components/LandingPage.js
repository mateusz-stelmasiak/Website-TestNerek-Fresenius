import {Link, useHistory} from "react-router-dom";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import "./LandingPage.css"
import ShareTest from "./ShareTest/ShareTest";



function LandingPage(){
    //routing after starting the test
    const history = useHistory();
    const startTest = () => history.push(process.env.REACT_APP_TOKEN+'/test');

    return (
        <section className="LandingPage">
            <Form className="startTest" onSubmit={startTest}>
                <Button type='submit'> Start testu </Button>
                <Form.Check
                    required
                    type='checkbox'
                    label={
                        <div>
                            Oświadczam, że zapoznałam/zapoznałem się z&nbsp;
                            <Link to={process.env.REACT_APP_TOKEN+'/polityka-prywatnosci'}>polityką prywatności</Link>
                            &nbsp;i akceptuję jej warunki.
                        </div>
                    }
                />
                <Form.Check
                    required
                    type='checkbox'
                    label={
                        <div>
                            Wyrażam zgodę na udostępnienie moich danych osobowych organizatorowi kampanii
                            <br/> społecznej OGÓLNOPOLSKI TEST ZDROWIA NEREK, w zakresie niezbędnym do jej
                            przeprowadzenia.
                        </div>
                    }
                />


            </Form>
            <ShareTest/>
        </section>
    );

}

export default LandingPage;