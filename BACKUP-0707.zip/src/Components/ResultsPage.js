import {useHistory} from "react-router-dom";
import "./ResultsPage.css"
import {useEffect, useState} from "react";
import {connect} from "react-redux";
import {latOrLata} from "../JSBackend";
import {calculateResult} from "../Redux/Actions/surveyActions";
import ShareTest from "./ShareTest/ShareTest";
import CountUp from "react-countup";
import Reel from 'react-reel'
import LabCodeGenerator from "./LabCode/LabCodeGenerator";



function ResultsPage({surveyResult,age,dispatch,}){
    const [loading,setLoading]=useState(true)

    async function loadResults(){
        setLoading(true);
        await dispatch(calculateResult(age))
        setLoading(false);
    }

    useEffect(()=>{
        loadResults()
    },[])


    return (
        <section >

            {surveyResult!==undefined && <div className="ResultsPage">
                <div className="resultContainer">
                    <h1>Wynik testu wskazuje, że Pani/Pana {surveyResult.header}</h1>
                    <div className="kidneyAge">
                        {surveyResult.result}
                    </div>
                    <h2>{surveyResult.verbose}</h2>
                </div>
                <LabCodeGenerator/>
                <ShareTest/>
            </div>
            }

        </section>
    );

}

const mapStateToProps = (state) => {
    return {
        age: state.user.userData.age,
        surveyResult: state.survey.surveyResult,
    };
};

export default connect(mapStateToProps)(ResultsPage);