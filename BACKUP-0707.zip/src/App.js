import './OverallStyle.css';
import {Provider} from "react-redux";
import {applyMiddleware, createStore} from "redux";
import rootReducer from "./Redux/Reducers/rootReducer";
import {composeWithDevTools} from "redux-devtools-extension";
import thunk from "redux-thunk";
import SurveyContainer from "./Components/SurveyPage";
import {BrowserRouter as Router, Redirect, Route,Switch} from 'react-router-dom';
import Banner from "./Components/Banner/Banner";
import LandingPage from "./Components/LandingPage";
import Footer from "./Components/Footer/Footer";
import ResultsPage from "./Components/ResultsPage";
import ScrollToTop from "./Components/ScrollToTop";
import PrivateRoute from "./Components/PrivateRoute";
import Privacy from "./Components/InfoPages/Privacy";
import Cookies from "./Components/InfoPages/Cookies";
import Law from "./Components/InfoPages/Law";
import UnderConstruction from "./Components/UnderConstruction";

//redux store

export const store = createStore(rootReducer, composeWithDevTools(applyMiddleware(thunk)))

//TODO this is a stupid way of going about it
//maybe change later?
function App() {
  return (
      <Provider store={store}>
          <Router>
                  <div className="App">
                      <ScrollToTop/>
                      <Switch>
                          <Route path={process.env.REACT_APP_TOKEN+"/test"}>
                              <Banner/>
                              <SurveyContainer/>
                              <Footer/>
                          </Route>
                          <PrivateRoute path={process.env.REACT_APP_TOKEN+"/wyniki"} >
                              <Banner/>
                              <ResultsPage/>
                              <Footer/>
                          </PrivateRoute>
                          <Route path={process.env.REACT_APP_TOKEN+"/polityka-prywatnosci"}>
                              <Banner/>
                              <Privacy/>
                              <Footer/>
                          </Route>
                          <Route path={process.env.REACT_APP_TOKEN+"/pliki-cookie"}>
                              <Banner/>
                              <Cookies/>
                              <Footer/>
                          </Route>
                          <Route path={process.env.REACT_APP_TOKEN+"/informacje-prawne"}>
                              <Banner/>
                              <Law/>
                              <Footer/>
                          </Route>
                          <Route path={process.env.REACT_APP_TOKEN+"/"}>
                              <Banner/>
                              <LandingPage/>
                              <Footer/>
                          </Route>
                          <Route path="/" exact component={UnderConstruction}/>
                          <Redirect from="*" to="/" />
                      </Switch>

                  </div>
          </Router>
      </Provider>
  );
}

//<Redirect from="*" to="/" />
//<Partners/>
export default App;
